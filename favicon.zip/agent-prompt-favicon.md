# Agent prompt: add the favicon set (Next.js App Router)

Paste this to the coding agent working on the The Mental Health site (dr-mithila.vercel.app). Attach the files from `favicon/` (or `favicon.zip`).

---

The site has no favicon. Add the attached favicon set using the Next.js App Router file conventions. Keep everything else unchanged.

**The mark:** the TMH logo tree with the "TMH" and "The Mental Health" text removed, in walnut brown on a transparent background. The 16 and 32 px versions are slightly thickened so the tree stays readable in a browser tab. The iPhone icon and the Android maskable icon sit on a cream `#FAF7F2` square. Do not use the full logo PNG (with text) as the favicon.

## 1. Files to place

| Attached file | Put it at | Why |
|---|---|---|
| `favicon.ico` (16, 32, 48 inside) | `app/favicon.ico` | Next serves `/favicon.ico` and adds the link tag |
| `favicon-32x32.png` | `app/icon.png` | PNG tab icon for modern browsers |
| `apple-touch-icon.png` (180, square, no rounding) | `app/apple-icon.png` | iOS home screen (iOS rounds the corners itself) |
| `icon-192.png`, `icon-512.png`, `icon-maskable-512.png` | `public/` | Used by the web manifest |

There is no SVG version, because the tree is a detailed traced logo. Delete any default `app/favicon.ico` from create-next-app before copying, and remove any old `icons` entry in `metadata` that points at other files, so there is one source of truth.

## 2. Web manifest

Create `app/manifest.ts`:

```ts
import type { MetadataRoute } from "next";

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: "The Mental Health, Dr. Mithila Desai",
    short_name: "The Mental Health",
    start_url: "/",
    display: "standalone",
    background_color: "#FAF7F2",
    theme_color: "#723E22",
    icons: [
      { src: "/icon-192.png", sizes: "192x192", type: "image/png" },
      { src: "/icon-512.png", sizes: "512x512", type: "image/png" },
      { src: "/icon-maskable-512.png", sizes: "512x512", type: "image/png", purpose: "maskable" },
    ],
  };
}
```

(Do not also add `site.webmanifest` to `public/`; `app/manifest.ts` replaces it.)

## 3. Theme colour

In `app/layout.tsx`, add (or extend) the viewport export:

```ts
import type { Viewport } from "next";
export const viewport: Viewport = { themeColor: "#723E22" };
```

## 4. Check before you finish

1. `npm run build` passes.
2. View source on `/` and confirm the head has `rel="icon"` for `/favicon.ico` and `/icon.png`, `rel="apple-touch-icon"`, `rel="manifest"` and `theme-color`.
3. Open `/favicon.ico`, `/icon.png`, `/apple-icon.png`, `/manifest.webmanifest`, `/icon-512.png`: each returns 200.
4. After deploying, hard refresh (browsers cache favicons hard; test in a private window).
